# Projeto de Detecção de Maturidade de Morangos

Este projeto utiliza o modelo YOLO de detecção de objetos para identificar e classificar morangos com base em seu estágio de maturação.

## Requisitos
- Python
- OpenCV (`cv2`)
- Ultralytics YOLO (`ultralytics`)

## Configuração

### Instalação de Dependências
```bash
pip install opencv-python ultralytics
```

### Modelo YOLO
Você precisa de um modelo YOLO treinado disponível. O nome do arquivo do modelo deve ser `best.pt` e ele deve ser colocado no diretório raiz do projeto.

## Uso

Certifique-se de que a webcam esteja conectada e funcionando corretamente antes de executar o script.

```bash
python ia.py
```

## Descrição do Código

1. **Inicialização da Webcam**: O código inicia uma conexão com a webcam e define a resolução das imagens capturadas.

2. **Carregamento do Modelo**: O modelo YOLO previamente treinado (`best.pt`) é carregado para predição.

3. **Classes de Objetos**: São definidas duas classes de objetos: 'maduro' e 'não maduro'.

4. **Processamento de Imagens**: As imagens capturadas pela webcam são processadas pelo modelo YOLO e os resultados são obtidos.
