from ultralytics import YOLO
import cv2
import math 
import time
import json
import datetime
import pyodbc

# Configurações de conexão
server = 'ia-morango-logs.database.windows.net'  # Substitua com o nome do servidor SQL Server
database = 'ia-morango-logs'  # Substitua com o nome do banco de dados
username = 'logs-admin'  # Substitua com seu nome de usuário
password = 'N#8H8@95#FTa'

# Estabeleça a conexão com o SQL Server
conn = pyodbc.connect(f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={database};UID={username};PWD={password}')
# cursor para executar consultas
cursor = conn.cursor()

# start webcam
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# model
model = YOLO("best.pt")

# object classes
classNames = ["ripe", "unripe"]

yolo_results = []

start_time = time.time()  # Salva o tempo no momento que o script começa
run_time = 20

while time.time() - start_time < run_time:
    success, img = cap.read()
    results = model(img, stream=True)
    
    # Inicializando contadores
    count_ripe = 0
    count_unripe = 0

    # coordinates
    for r in results:
        boxes = r.boxes

        for box in boxes:
            # bounding box
            x1, y1, x2, y2 = box.xyxy[0]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2) # convert to int values

            # put box in cam
            cv2.rectangle(img, (x1, y1), (x2, y2), (255, 0, 255), 3)

            # confidence
            confidence = math.ceil((box.conf[0]*100))/100
            print("Confidence --->",confidence)
        
            # class name
            cls = int(box.cls[0])
            print("Class name -->", classNames[cls])

            # Atualizando contadores com base na classe detectada
            if classNames[cls] == 'ripe':
                count_ripe += 1
            elif classNames[cls] == 'unripe':
                count_unripe += 1

            # object details
            org = [x1, y1]
            font = cv2.FONT_HERSHEY_SIMPLEX
            fontScale = 1
            color = (255, 0, 0)
            thickness = 2

            current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            yolo_results.append({
                "date_time": current_datetime,
                "confidence": confidence,
                "ripe_count": count_ripe,
                "unripe_count": count_unripe
            })

            cv2.putText(img, classNames[cls], org, font, fontScale, color, thickness)

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

with open("yolo_results.json", "w") as file:
    file.write('[')
    
    for idx, result in enumerate(yolo_results):
        if idx != 0:
            file.write(',')
        
        file.write(json.dumps(result))
    
    file.write(']')

# Carregue os registros do arquivo JSON
with open("yolo_results.json", "r") as file:
    items = json.load(file)
    
    sql_query = "INSERT INTO logs (date_time, confidence, ripe_count, unripe_count) VALUES (?, ?, ?, ?)"
    cursor.executemany(sql_query, [(item["date_time"], item["confidence"], item["ripe_count"], item["unripe_count"]) for item in items])
    conn.commit()

# Feche a conexão
conn.close()
